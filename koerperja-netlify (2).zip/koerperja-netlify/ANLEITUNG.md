# KörperJa Freude-Code – Netlify-Deployment

## Update: 502-Fehler behoben (Timeout-Problem)
Falls du schonmal deployt hattest und einen **502-Fehler** bekommen hast: Das
lag daran, dass normale Netlify Functions nur 10 Sekunden laufen dürfen –
die KI-Analyse braucht aber oft länger. Diese Version nutzt stattdessen eine
**Netlify Edge Function mit Streaming**, die dieses Limit nicht hat. Wenn du
die Dateien schon mal hochgeladen hattest, ersetze sie unbedingt durch diese
neue Version (siehe "Update-Schritte" ganz unten).

## Warum es ursprünglich nicht ging
Dein HTML-Tool hat die Anthropic-API direkt aus dem Browser heraus aufgerufen.
Das funktioniert aus zwei Gründen nicht:
1. Es wurde gar kein API-Schlüssel mitgeschickt (auf claude.ai übernimmt das
   die Plattform automatisch im Hintergrund – das geht aber nur dort).
2. Anthropic blockiert direkte Browser-Aufrufe an ihre API aus Sicherheitsgründen
   (CORS) – und selbst wenn es ginge, dürfte der Schlüssel niemals im
   Frontend-Code stehen, da ihn sonst jeder über "Seitenquelltext anzeigen"
   auslesen könnte.

## Die Lösung: eine Netlify Edge Function als sicherer Vermittler
Diese Dateien sind bereits fertig aufgesetzt:
- `index.html` – dein Tool (ruft jetzt `/api/analyze` auf und liest die
  Antwort per Streaming, Stückchen für Stückchen)
- `netlify/edge-functions/analyze.js` – läuft serverseitig bei Netlify, hält
  den API-Schlüssel geheim und reicht die Streaming-Antwort von Anthropic
  direkt durch
- `netlify.toml` – sagt Netlify, wo die Edge Function liegt und unter welcher
  Adresse (`/api/analyze`) sie erreichbar ist

## Schritt-für-Schritt (WICHTIG: nicht per Drag & Drop!)

⚠️ Netlifys einfaches **Drag & Drop** im Dashboard veröffentlicht meist nur
die statischen Dateien (HTML/CSS/JS) – Functions/Edge Functions werden dabei
oft NICHT mit eingerichtet. Das ist eine bekannte Einschränkung von Netlify,
kein Fehler von dir. Nutze stattdessen einen der folgenden zwei Wege:

### Weg A – Netlify CLI (empfohlen, dauert ca. 5 Minuten)

1. Falls noch nicht vorhanden: [Node.js](https://nodejs.org) installieren.
2. Terminal öffnen (Mac: "Terminal"-App, Windows: "Eingabeaufforderung"),
   in den entpackten Ordner wechseln, z.B.:
   ```
   cd Downloads/koerperja-netlify
   ```
3. Netlify CLI installieren:
   ```
   npm install -g netlify-cli
   ```
4. Bei Netlify einloggen (öffnet den Browser):
   ```
   netlify login
   ```
5. Mit deiner bestehenden Netlify-Seite verknüpfen:
   ```
   netlify link
   ```
   (wähle deine bereits erstellte Seite aus der Liste aus)
6. Deployen:
   ```
   netlify deploy --prod
   ```
7. Im Terminal sollte jetzt "Edge Functions" mit `analyze` aufgelistet werden
   – damit ist sichergestellt, dass sie wirklich mit hochgeladen wurde.

### Weg B – GitHub-Repository verbinden (dein bisheriger Weg)

1. Alle Dateien aus diesem Ordner (inkl. `netlify/`-Unterordner) in dein
   bestehendes GitHub-Repository hochladen ("Add file" → "Upload files").
   Wichtig: `netlify/functions/analyze.js` (die alte Datei) gibt es nicht
   mehr – lösche sie im Repo, falls sie noch von vorher drinliegt, und lade
   stattdessen `netlify/edge-functions/analyze.js` hoch.
2. Netlify baut die Seite beim nächsten Deploy automatisch inkl. Edge
   Function – dein Base-directory ist ja schon korrekt eingestellt.

### Nach Weg A oder B: API-Schlüssel prüfen

1. **API-Schlüssel als Umgebungsvariable** (falls noch nicht geschehen):
   - Netlify-Dashboard → dein Projekt → **Site configuration** →
     **Environment variables** → **Add a variable**
   - Key: `ANTHROPIC_API_KEY`
   - Value: dein Schlüssel von console.anthropic.com (beginnt mit `sk-ant-...`)
   - Speichern

2. **Neu deployen** (Environment-Variablen greifen erst nach einem neuen
   Deploy) – bei Weg A einfach `netlify deploy --prod` erneut ausführen, bei
   Weg B im Dashboard "Trigger deploy" → "Deploy site".

3. Fertig – dein Tool läuft jetzt unter deiner Netlify-URL und die Analyse
   sollte sich erstellen lassen, auch wenn sie länger dauert.

## Falls es weiterhin nicht klappt
Öffne die Browser-Konsole (Rechtsklick → "Untersuchen" → Tab "Console") und
schau nach einer Fehlermeldung – die neue Version zeigt jetzt eine genaue
Fehlermeldung im Tool selbst an, statt nur "etwas ist schiefgelaufen".
Häufigste Ursachen:
- Per Drag & Drop deployt statt über CLI oder GitHub (siehe oben)
- Alte `netlify/functions/analyze.js` liegt noch im Repo und verwirrt Netlify
  → löschen, nur `netlify/edge-functions/analyze.js` soll übrig bleiben
- Umgebungsvariable falsch benannt (muss exakt `ANTHROPIC_API_KEY` heißen)
- Kein Guthaben/keine Zahlungsmethode im Anthropic-Konsole-Account hinterlegt

